package com.donutmoney.client;

import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_310;

import static net.fabricmc.fabric.api.client.command.v2.ClientCommandManager.argument;
import static net.fabricmc.fabric.api.client.command.v2.ClientCommandManager.literal;

public final class ClientCommands {
    private ClientCommands() {}

    public static void register() {
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) -> {
            dispatcher.register(literal("moneyapikey")
                .then(argument("key", StringArgumentType.greedyString())
                    .executes((ctx) -> {
                        String key = StringArgumentType.getString(ctx, "key");
                        key = String.valueOf(key == null ? "" : key).trim();
                        if (key.isEmpty()) return 0;
                        ModConfig cfg = ModConfig.get();
                        cfg.donutApiKey = key;
                        ModConfig.save();
                        LeaderboardManager.forceUpdate();
                        class_310 mc = class_310.method_1551();
                        if (mc.field_1724 != null) {
                            mc.field_1724.method_7353(class_2561.method_43470("Donut Money Display: saved API key.").method_27692(class_124.field_1060), false);
                        }
                        return 1;
                    })
                )
                .executes((ctx) -> {
                    class_310 mc = class_310.method_1551();
                    if (mc.field_1724 != null) {
                        mc.field_1724.method_7353(class_2561.method_43470("Usage: /moneyapikey <key>").method_27692(class_124.field_1054), false);
                    }
                    return 1;
                })
            );
        });
    }
}

