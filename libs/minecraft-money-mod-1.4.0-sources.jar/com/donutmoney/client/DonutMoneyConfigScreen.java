package com.donutmoney.client;

import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public final class DonutMoneyConfigScreen extends class_437 {
    private final class_437 parent;
    private class_342 apiInput;

    public DonutMoneyConfigScreen(class_437 parent) {
        super(class_2561.method_43470("Donut Money Display"));
        this.parent = parent;
    }

    @Override
    protected void method_25426() {
        int w = this.field_22789;
        int labelY = 60;
        int inputY = 78;
        int inputW = Math.min(320, w - 40);
        int inputX = (w - inputW) / 2;

        this.apiInput = new class_342(this.field_22793, inputX, inputY, inputW, 20, class_2561.method_43470("DonutSMP API"));
        String cur = "";
        try {
            ModConfig cfg = ModConfig.get();
            cur = cfg == null ? "" : String.valueOf(cfg.donutApiKey == null ? "" : cfg.donutApiKey);
        } catch (Throwable ignored) {
        }
        this.apiInput.method_1852(cur);
        this.apiInput.method_1880(256);
        this.method_37063(this.apiInput);

        this.method_37063(class_4185.method_46430(class_2561.method_43470("Save"), (b) -> {
            saveAndClose();
        }).method_46434((w / 2) - 105, this.field_22790 - 40, 100, 20).method_46431());

        this.method_37063(class_4185.method_46430(class_2561.method_43470("Cancel"), (b) -> {
            method_25419();
        }).method_46434((w / 2) + 5, this.field_22790 - 40, 100, 20).method_46431());

        this.method_48265(this.apiInput);
    }

    private void saveAndClose() {
        String v = this.apiInput == null ? "" : String.valueOf(this.apiInput.method_1882());
        v = v.trim();
        if (!v.isEmpty()) {
            ModConfig cfg = ModConfig.get();
            cfg.donutApiKey = v;
            ModConfig.save();
            LeaderboardManager.forceUpdate();
        }
        method_25419();
    }

    @Override
    public void method_25419() {
        class_310.method_1551().method_1507(parent);
    }

    @Override
    public void method_25394(net.minecraft.class_332 guiGraphics, int mouseX, int mouseY, float delta) {
        super.method_25394(guiGraphics, mouseX, mouseY, delta);
        guiGraphics.method_27534(this.field_22793, class_2561.method_43470("DonutSMP API:"), this.field_22789 / 2, 60, 0xFFFFFF);
    }
}

