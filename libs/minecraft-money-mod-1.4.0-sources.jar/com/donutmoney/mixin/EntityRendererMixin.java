package com.donutmoney.mixin;

import com.donutmoney.client.IMoneyRenderState;
import com.donutmoney.client.ModConfig;
import com.donutmoney.client.MoneyManager;
import com.donutmoney.client.LeaderboardManager;
import com.donutmoney.client.DebugLog;
import com.donutmoney.client.DonutMoneyClient;
import java.util.List;
import net.minecraft.class_10017;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_897;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_897.class)
public abstract class EntityRendererMixin<T extends class_1297> {
    @Inject(method = "extractRenderState", at = @At("RETURN"), require = 0)
    private void donutmoney$extractRenderState(class_1297 entity, class_10017 state, float f, CallbackInfo ci) {
        try {
            if (!(state instanceof IMoneyRenderState moneyState)) return;
            ModConfig cfg = ModConfig.get();
            if (cfg == null || !cfg.showMoney) {
                moneyState.setShouldRenderMoney(false);
                return;
            }
            if (!(entity instanceof class_1657 p)) {
                moneyState.setShouldRenderMoney(false);
                return;
            }

            class_310 mc = class_310.method_1551();
            if (mc.field_1724 == null) {
                moneyState.setShouldRenderMoney(false);
                return;
            }

            boolean shouldRender = !entity.method_5767() && !entity.method_21751() && mc.field_1724.method_5858(entity) <= 4096.0D;
            moneyState.setShouldRenderMoney(shouldRender);
            if (!shouldRender) return;

            double distSq = mc.field_1724.method_5858(entity);
            boolean fast = distSq <= 256.0D;

            String name = p.method_5820();
            moneyState.setPlayerName(name);
            String moneyText = MoneyManager.getFormattedMoney(name, fast);
            if (moneyText == null || moneyText.isEmpty()) moneyText = "...";
            moneyState.setMoneyText("$" + moneyText);

            if (cfg.showLeaderboardRank) {
                LeaderboardManager.tick();
                moneyState.setRanks(LeaderboardManager.getPlayerRanks(name));
            } else {
                moneyState.setRanks(null);
            }
        } catch (Throwable ignored) {
        }
    }

    @Inject(method = "renderNameTag(Lnet/minecraft/client/renderer/entity/state/EntityRenderState;Lnet/minecraft/network/chat/Component;Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;I)V", at = @At("HEAD"), require = 0)
    private void donutmoney$shiftOtherNameTags(class_10017 state, class_2561 displayName, class_4587 poseStack, class_4597 bufferSource, int packedLight, CallbackInfo ci) {
        try {
            if (!(state instanceof IMoneyRenderState moneyState)) return;
            if (!moneyState.shouldRenderMoney()) return;
            if (moneyState.getTagShiftY() != 0.0F) return;

            String playerName = String.valueOf(moneyState.getPlayerName() == null ? "" : moneyState.getPlayerName()).trim();
            if (playerName.isEmpty()) return;
            String disp = displayName == null ? "" : String.valueOf(displayName.getString());
            if (disp.contains(playerName)) return;

            ModConfig cfg = ModConfig.get();
            if (cfg == null || !cfg.showMoney) return;

            class_327 font = class_310.method_1551().field_1772;
            float line = font.field_2000 + 2.0F;
            float scale = cfg.scalePercent / 100.0F;
            float shiftY = (line * scale) + 2.0F;

            moneyState.setTagShiftY(shiftY);
            poseStack.method_46416(0.0F, shiftY, 0.0F);
        } catch (Throwable ignored) {
        }
    }

    @Inject(method = "renderNameTag(Lnet/minecraft/client/renderer/entity/state/EntityRenderState;Lnet/minecraft/network/chat/Component;Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;I)V", at = @At(value = "INVOKE", target = "Lcom/mojang/blaze3d/vertex/PoseStack;popPose()V", shift = At.Shift.BEFORE), require = 0)
    private void donutmoney$renderMoneyTagState(class_10017 state, class_2561 displayName, class_4587 poseStack, class_4597 bufferSource, int packedLight, CallbackInfo ci) {
        boolean pushed = false;
        try {
            if (!(state instanceof IMoneyRenderState moneyState)) return;
            if (!moneyState.shouldRenderMoney()) return;
            class_310 mc = class_310.method_1551();
            if (mc.field_1687 == null) return;
            long tick = mc.field_1687.method_8510();
            if (moneyState.getLastRenderedTick() == tick) return;
            moneyState.setLastRenderedTick(tick);
            ModConfig cfg = ModConfig.get();
            if (cfg == null || !cfg.showMoney) return;
            String playerName = String.valueOf(moneyState.getPlayerName() == null ? "" : moneyState.getPlayerName()).trim();
            if (playerName.isEmpty()) return;
            String text = moneyState.getMoneyText();
            if (text == null || text.isEmpty()) return;

            class_327 font = mc.field_1772;
            float scale = cfg.scalePercent / 100.0F;
            List<LeaderboardManager.RankData> ranks = moneyState.getRanks();
            boolean hasRanks = cfg.showLeaderboardRank && ranks != null && !ranks.isEmpty();
            int moneyWidth = font.method_1727(text);
            int spaceGap = font.method_1727(" ");
            int segGap = spaceGap;
            int mainGap = hasRanks ? spaceGap : 0;
            float mini = 0.85F;
            float ranksWidth = 0.0F;
            if (hasRanks) {
                for (LeaderboardManager.RankData r : ranks) {
                    if (r == null) continue;
                    int rk = r.rank();
                    if (rk <= 0 || rk > 1000) continue;
                    String icon = String.valueOf(r.symbol());
                    String prefix = String.valueOf(r.type()) + " #";
                    String rankStr = String.valueOf(rk);
                    float iconW = font.method_1727(icon);
                    float overlap = iconW * 0.5F;
                    float w = iconW + ((font.method_1727(prefix) + font.method_1727(rankStr)) * mini) - overlap;
                    if (ranksWidth > 0.0F) ranksWidth += segGap;
                    ranksWidth += w;
                }
            }
            float startX = -((ranksWidth + mainGap + moneyWidth) / 2.0F);

            float line = font.field_2000 + 2.0F;
            float yMoney = (float) (cfg.yOffset + 2.0F);
            poseStack.method_22903();
            pushed = true;
            poseStack.method_22905(scale, scale, 1.0F);


            Matrix4f m = poseStack.method_23760().method_23761();
            int light = 15728880;
            int background = 0;
            if (cfg.showBackground) {
                float bgOp = mc.field_1690.method_19343(0.25F);
                background = (int) (bgOp * 255.0F) << 24;
            }
            int lbBackground = 0;

            float xCursor = startX;
            if (hasRanks) {
                boolean first = true;
                for (LeaderboardManager.RankData r : ranks) {
                    if (r == null) continue;
                    int rk = r.rank();
                    if (rk <= 0 || rk > 1000) continue;
                    String icon = String.valueOf(r.symbol());
                    String prefix = String.valueOf(r.type()) + " #";
                    String rankStr = String.valueOf(rk);
                    if (!first) xCursor += segGap;
                    first = false;

                    int iconRgb = r.color() & 0x00FFFFFF;
                    int alpha70 = 0xB3;
                    int iconCol = (alpha70 << 24) | iconRgb;
                    int labelCol = 0xFFFFFFFF;
                    int rankCol = (0xFF << 24) | iconRgb;

                    float iconW = font.method_1727(icon);
                    float overlap = iconW * 0.5F;
                    font.method_27521(icon, xCursor, yMoney, iconCol, true, m, bufferSource, class_327.class_6415.field_33993, lbBackground, light);
                    xCursor += iconW - overlap;

                    boolean pushedInner = false;
                    try {
                        poseStack.method_22903();
                        pushedInner = true;
                        poseStack.method_46416(xCursor, yMoney + 1.5F, 0.0F);
                        poseStack.method_22905(mini, mini, 1.0F);
                        Matrix4f m2 = poseStack.method_23760().method_23761();
                        font.method_27521(prefix, 0.0F, 0.0F, labelCol, true, m2, bufferSource, class_327.class_6415.field_33993, lbBackground, light);
                        float rx = font.method_1727(prefix);
                        font.method_27521(rankStr, rx, 0.0F, rankCol, true, m2, bufferSource, class_327.class_6415.field_33993, lbBackground, light);
                    } finally {
                        if (pushedInner) poseStack.method_22909();
                    }

                    xCursor += (font.method_1727(prefix) + font.method_1727(rankStr)) * mini;
                }
                if (xCursor != startX) xCursor += mainGap;
            }
            font.method_27521(text, xCursor, yMoney, 0x55FF55, false, m, bufferSource, class_327.class_6415.field_33993, background, light);
        } catch (Throwable ignored) {
        } finally {
            if (pushed) {
                try {
                    poseStack.method_22909();
                } catch (Throwable ignored) {
                }
            }
        }
    }

    @Inject(method = "renderNameTag(Lnet/minecraft/client/renderer/entity/state/EntityRenderState;Lnet/minecraft/network/chat/Component;Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;I)V", at = @At("RETURN"), require = 0)
    private void donutmoney$unshiftOtherNameTags(class_10017 state, class_2561 displayName, class_4587 poseStack, class_4597 bufferSource, int packedLight, CallbackInfo ci) {
        try {
            if (!(state instanceof IMoneyRenderState moneyState)) return;
            float shiftY = moneyState.getTagShiftY();
            if (shiftY == 0.0F) return;
            moneyState.setTagShiftY(0.0F);
            poseStack.method_46416(0.0F, -shiftY, 0.0F);
        } catch (Throwable ignored) {
        }
    }

    @Inject(method = "renderNameTag(Lnet/minecraft/client/renderer/entity/state/EntityRenderState;Lnet/minecraft/network/chat/Component;Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;IF)V", at = @At("HEAD"), require = 0)
    private void donutmoney$shiftOtherNameTags(class_10017 state, class_2561 displayName, class_4587 poseStack, class_4597 bufferSource, int packedLight, float tickDelta, CallbackInfo ci) {
        try {
            if (!(state instanceof IMoneyRenderState moneyState)) return;
            if (!moneyState.shouldRenderMoney()) return;
            if (moneyState.getTagShiftY() != 0.0F) return;

            String playerName = String.valueOf(moneyState.getPlayerName() == null ? "" : moneyState.getPlayerName()).trim();
            if (playerName.isEmpty()) return;
            String disp = displayName == null ? "" : String.valueOf(displayName.getString());
            if (disp.contains(playerName)) return;

            ModConfig cfg = ModConfig.get();
            if (cfg == null || !cfg.showMoney) return;

            class_327 font = class_310.method_1551().field_1772;
            float line = font.field_2000 + 2.0F;
            float scale = cfg.scalePercent / 100.0F;
            float shiftY = (line * scale) + 2.0F;

            moneyState.setTagShiftY(shiftY);
            poseStack.method_46416(0.0F, shiftY, 0.0F);
        } catch (Throwable ignored) {
        }
    }

    @Inject(method = "renderNameTag(Lnet/minecraft/client/renderer/entity/state/EntityRenderState;Lnet/minecraft/network/chat/Component;Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;IF)V", at = @At(value = "INVOKE", target = "Lcom/mojang/blaze3d/vertex/PoseStack;popPose()V", shift = At.Shift.BEFORE), require = 0)
    private void donutmoney$renderMoneyTagState(class_10017 state, class_2561 displayName, class_4587 poseStack, class_4597 bufferSource, int packedLight, float tickDelta, CallbackInfo ci) {
        donutmoney$renderMoneyTagState(state, displayName, poseStack, bufferSource, packedLight, ci);
    }

    @Inject(method = "renderNameTag(Lnet/minecraft/client/renderer/entity/state/EntityRenderState;Lnet/minecraft/network/chat/Component;Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;IF)V", at = @At("RETURN"), require = 0)
    private void donutmoney$unshiftOtherNameTags(class_10017 state, class_2561 displayName, class_4587 poseStack, class_4597 bufferSource, int packedLight, float tickDelta, CallbackInfo ci) {
        try {
            if (!(state instanceof IMoneyRenderState moneyState)) return;
            float shiftY = moneyState.getTagShiftY();
            if (shiftY == 0.0F) return;
            moneyState.setTagShiftY(0.0F);
            poseStack.method_46416(0.0F, -shiftY, 0.0F);
        } catch (Throwable ignored) {
        }
    }

}
