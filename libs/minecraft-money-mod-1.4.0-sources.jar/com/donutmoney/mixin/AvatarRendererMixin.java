package com.donutmoney.mixin;

import com.donutmoney.client.IMoneyRenderState;
import com.donutmoney.client.LeaderboardManager;
import com.donutmoney.client.ModConfig;
import com.donutmoney.client.MoneyManager;
import java.util.List;
import net.minecraft.class_10055;
import net.minecraft.class_1007;
import net.minecraft.class_11659;
import net.minecraft.class_11785;
import net.minecraft.class_11890;
import net.minecraft.class_12075;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_4587;
import net.minecraft.class_5481;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1007.class)
public class AvatarRendererMixin {
    @Inject(method = "extractRenderState", at = @At("TAIL"), require = 0)
    private void donutmoney$extractState(class_11890 avatar, class_10055 state, float tickDelta, CallbackInfo ci) {
        try {
            if (!(state instanceof IMoneyRenderState moneyState)) return;
            class_310 mc = class_310.method_1551();
            if (mc.field_1724 == null) return;
            if (avatar == null) return;

            ModConfig cfg = ModConfig.get();
            if (cfg == null || !cfg.showMoney) {
                moneyState.setShouldRenderMoney(false);
                return;
            }

            boolean shouldRender = !avatar.method_5767() && !avatar.method_21751() && mc.field_1724.method_5858(avatar) <= 4096.0D;
            moneyState.setShouldRenderMoney(shouldRender);
            moneyState.setPlayerName(avatar.method_5820());

            if (!shouldRender) return;

            boolean fast = mc.field_1724.method_5858(avatar) <= 256.0D;
            String name = String.valueOf(moneyState.getPlayerName() == null ? "" : moneyState.getPlayerName());
            String moneyText = MoneyManager.getFormattedMoney(name, fast);
            if (moneyText == null || moneyText.isEmpty()) moneyText = "...";
            moneyState.setMoneyText("$" + moneyText);

            if (cfg.showLeaderboardRank) {
                LeaderboardManager.tick();
                moneyState.setRanks(LeaderboardManager.getPlayerRanks(name));
            } else {
                moneyState.setRanks(null);
            }
        } catch (Throwable ignored) {
        }
    }

    @Inject(method = "submitNameTag", at = @At(value = "INVOKE", target = "Lcom/mojang/blaze3d/vertex/PoseStack;popPose()V", shift = At.Shift.BEFORE), require = 0)
    private void donutmoney$renderMoneyTag(class_10055 state, class_4587 poseStack, class_11659 collector, class_12075 camera, CallbackInfo ci) {
        boolean pushed = false;
        try {
            if (!(state instanceof IMoneyRenderState moneyState)) return;
            if (!moneyState.shouldRenderMoney()) return;

            class_310 mc = class_310.method_1551();
            if (mc.field_1687 == null) return;
            long tick = mc.field_1687.method_8510();
            if (moneyState.getLastRenderedTick() == tick) return;
            moneyState.setLastRenderedTick(tick);

            ModConfig cfg = ModConfig.get();
            if (cfg == null || !cfg.showMoney) return;
            String text = moneyState.getMoneyText();
            if (text == null || text.isEmpty()) return;

            class_327 font = mc.field_1772;
            float scale = cfg.scalePercent / 100.0F;
            List<LeaderboardManager.RankData> ranks = moneyState.getRanks();
            boolean hasRanks = cfg.showLeaderboardRank && ranks != null && !ranks.isEmpty();
            int moneyWidth = font.method_1727(text);
            int spaceGap = font.method_1727(" ");
            int segGap = spaceGap;
            int mainGap = hasRanks ? spaceGap : 0;
            float mini = 0.85F;

            float ranksWidth = 0.0F;
            if (hasRanks) {
                for (LeaderboardManager.RankData r : ranks) {
                    if (r == null) continue;
                    int rk = r.rank();
                    if (rk <= 0 || rk > 1000) continue;
                    String icon = String.valueOf(r.symbol());
                    String prefix = String.valueOf(r.type()) + " #";
                    String rankStr = String.valueOf(rk);
                    float iconW = font.method_1727(icon);
                    float overlap = iconW * 0.5F;
                    float w = iconW + ((font.method_1727(prefix) + font.method_1727(rankStr)) * mini) - overlap;
                    if (ranksWidth > 0.0F) ranksWidth += segGap;
                    ranksWidth += w;
                }
            }

            float startX = -((ranksWidth + mainGap + moneyWidth) / 2.0F);
            float yMoney = (float) (cfg.yOffset + 2.0F);

            poseStack.method_22903();
            pushed = true;
            poseStack.method_22905(scale, scale, 1.0F);

            int light = 15728880;
            int background = 0;
            if (cfg.showBackground) {
                float bgOp = mc.field_1690.method_19343(0.25F);
                background = (int) (bgOp * 255.0F) << 24;
            }
            int lbBackground = 0;
            class_11785 ordered = collector.method_73529(0);

            float xCursor = startX;
            if (hasRanks) {
                boolean first = true;
                for (LeaderboardManager.RankData r : ranks) {
                    if (r == null) continue;
                    int rk = r.rank();
                    if (rk <= 0 || rk > 1000) continue;
                    String icon = String.valueOf(r.symbol());
                    String prefix = String.valueOf(r.type()) + " #";
                    String rankStr = String.valueOf(rk);
                    if (!first) xCursor += segGap;
                    first = false;

                    int iconRgb = r.color() & 0x00FFFFFF;
                    int alpha70 = 0xB3;
                    int iconCol = (alpha70 << 24) | iconRgb;
                    int labelCol = 0xFFFFFFFF;
                    int rankCol = (0xFF << 24) | iconRgb;

                    float iconW = font.method_1727(icon);
                    float overlap = iconW * 0.5F;
                    class_5481 iconSeq = class_2561.method_43470(icon).method_30937();
                    ordered.method_73478(poseStack, xCursor, yMoney, iconSeq, true, class_327.class_6415.field_33993, iconCol, lbBackground, light, 0);
                    xCursor += iconW - overlap;

                    boolean pushedInner = false;
                    try {
                        poseStack.method_22903();
                        pushedInner = true;
                        poseStack.method_46416(xCursor, yMoney + 1.5F, 0.0F);
                        poseStack.method_22905(mini, mini, 1.0F);
                        class_5481 prefixSeq = class_2561.method_43470(prefix).method_30937();
                        ordered.method_73478(poseStack, 0.0F, 0.0F, prefixSeq, true, class_327.class_6415.field_33993, labelCol, lbBackground, light, 0);
                        float rx = font.method_1727(prefix);
                        class_5481 rankSeq = class_2561.method_43470(rankStr).method_30937();
                        ordered.method_73478(poseStack, rx, 0.0F, rankSeq, true, class_327.class_6415.field_33993, rankCol, lbBackground, light, 0);
                    } finally {
                        if (pushedInner) poseStack.method_22909();
                    }

                    xCursor += (font.method_1727(prefix) + font.method_1727(rankStr)) * mini;
                }
                if (xCursor != startX) xCursor += mainGap;
            }

            class_5481 moneySeq = class_2561.method_43470(text).method_30937();
            ordered.method_73478(poseStack, xCursor, yMoney, moneySeq, false, class_327.class_6415.field_33993, 0x55FF55, background, light, 0);
        } catch (Throwable ignored) {
        } finally {
            if (pushed) {
                try {
                    poseStack.method_22909();
                } catch (Throwable ignored) {
                }
            }
        }
    }
}
